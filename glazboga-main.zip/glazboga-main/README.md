<a href="https://www.youtube.com/c/DimonDev?sub_confirmation=1"><img src="https://i.pinimg.com/originals/a5/10/2e/a5102eada32982c1ccac65804eab67c1.png" height="50px"></a> <a href="https://t.me/dimondevchat"><img src="https://i1.wp.com/www.sscnaukari.in/wp-content/uploads/2018/09/telegram.png?fit=2521%2C788&ssl=1" height="50px"></a>
<h1 align="center"><b>Глаз Бога</b></h1>
<p align="center">Это моя версия телеграм бота Глаз Бога. Работает прекрасно, стабильно и выдает много информации:</p>
<p align="center">Сделан программистом DimonDev: https://youtube.com/dimondev</p>
<h3 align="center"><a href="https://t.me/t3_avtootvetchik_bot"> > А вот бот в ТЕЛЕГРАМЕ < </a></h3>
<h3 align="center"><img src="Снимок13.PNG" alt="god" height="500px"></h3>
<h1 align="center"><b>Установка</b></h1>
<p>Он устанавливается очень просто:</p>

```
git clone https://github.com/SegYT/glazboga
cd glazboga
pip install -r requirements.txt
```
<p>Теперь запускаем скрипт:</p>

```
python main.py
```

<p>Если ты сделал все правильно, то программа должна написать:</p>

```
!BOT STARTED!
```
